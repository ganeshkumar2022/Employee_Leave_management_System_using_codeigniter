<ul class="nav mynav flex-column">
<li class="nav-item">
    <img src="<?=base_url('assets/image/logo.png')?>" class="img-fluid">
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?=base_url('user')?>"><i class="fa-solid fa-user"></i>&nbsp;&nbsp;&nbsp;Apply Leave</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?=base_url('user/view_leave')?>"><i class="fa-solid fa-paste"></i>&nbsp;&nbsp;&nbsp;View my Leave history</a>
  </li>
</ul>

