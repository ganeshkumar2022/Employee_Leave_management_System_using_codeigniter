
<div class="dropdown">
  <button type="button" class="float-right btn btn-primary btn-lg" data-toggle="dropdown">
    <img src="<?=base_url('assets/image/admin.png')?>" style="height:50px;">Admin&nbsp;&nbsp;<i class="fa-solid fa-angle-down small"></i>
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="<?=base_url('admin/change_password')?>">Change password</a>
    <a class="dropdown-item" href="<?=base_url('admin/logout')?>">Logout</a>
  </div>
</div>
